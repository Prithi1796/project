package com.wms.servletcontroller;

import java.util.*;

public class weatherApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String location="pallavaram";
		/*WeatherDao weatherDao= new WeatherDao();
		Map<String,String> map= new HashMap<String,String>();
		
		String update=weatherDao.getStatus(loc);
		map.put(loc, update);
		System.out.println(map);*/
		WeatherDao weatherDao=new WeatherDao();
		//WeatherBean weatherBean=new WeatherBean();
	//	weatherBean.setLocation("pallavaram");
		//String update= weatherDao.getStatus(weatherBean.getLocation());
		//Map<String,String> map = new HashMap<String,String>();
		//if(map.containsKey(weatherBean.getLocation()))
			//System.out.println(map);
		//<WeatherBean> update1=weatherDao.getStatus(location);
		List<WeatherBean> update1= weatherDao.abc();
		Iterator<WeatherBean> itr=update1.iterator();
		
		System.out.println("Humidity  Rainfall  Temperature  Windspeed");
		while(itr.hasNext())
		{
			WeatherBean weatherBean=itr.next();
			
			System.out.print(weatherBean.getSunrise()+ "  ");
			System.out.print(weatherBean.getSunset()+"  ");
			System.out.print(weatherBean.getMoonrise()+"  ");
			System.out.println(weatherBean.getMoonset()+"  ");
			System.out.print(weatherBean.getHumidity()+ "  ");
			

		}
			
		

	}

}
