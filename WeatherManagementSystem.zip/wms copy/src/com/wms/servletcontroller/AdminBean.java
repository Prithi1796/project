package com.wms.servletcontroller;

public class AdminBean {
	private String location,b_update,m_update;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getB_update() {
		return b_update;
	}

	public void setB_update(String b_update) {
		this.b_update = b_update;
	}

	public String getM_update() {
		return m_update;
	}

	public void setM_update(String m_update) {
		this.m_update = m_update;
	}
	

}
