package com.wms.servletcontroller;
import java.sql.*;
import java.util.*;

import com.inautix.sample.weather.UserBean;
public class WeatherDao {
	
	public List<WeatherBean> getUpdate(String city,String temp,String humid,String windspeed,String rainfall)
	{
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
	//	Map map=null;
		ResultSet resultset = null;
		List<WeatherBean> update1=null;
		//String searchQuery = "SELECT *  from T_XBBNHF7_WEATHER1";
		String searchQuery = "INSERT INTO T_XBBNHF7_WEATHER1 VALUES (?,?, ?, ?, ?)";

		try {
			 stmt = conn.prepareStatement(searchQuery);		
			
			 
			
			 stmt.setString(1, city);
			 stmt.setString(2, temp);
			 stmt.setString(3, humid);
			 stmt.setString(4, windspeed);
			 stmt.setString(5, rainfall);
					
			
			  stmt.executeUpdate();	
			 update1=new ArrayList<WeatherBean>();
			 
			
			 //map = new HashMap<String,String>();
			 
			/*while(resultset.next()) {
				WeatherBean weatherBean = new WeatherBean();
				weatherBean.setHumidity(resultset.getString("HUMIDITY"));
				weatherBean.setRainfall(resultset.getString("RAINFALL"));
				weatherBean.setTemperature(resultset.getString("TEMPERATURE"));
				weatherBean.setWindspeed(resultset.getString("WINDSPEED"));
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				update1.add(weatherBean);*/
				
						
			//}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
	
	
	}

	
	public List<WeatherBean> getUpdate1()
	{
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
	//	Map map=null;
		ResultSet resultset = null;
		List<WeatherBean> update1=null;
		//String searchQuery = "SELECT *  from T_XBBNHF7_WEATHER1";
		String searchQuery = "SELECT * FROM T_XBBNHF7_WEATHER1 where LOCATION='Chennai'";

		try {
			 stmt = conn.prepareStatement(searchQuery);		
					
			
			  resultset=stmt.executeQuery();	
			  update1=new ArrayList<WeatherBean>();
			  
			  while(resultset.next()) {
					WeatherBean wBean = new WeatherBean();
					wBean.setCity(resultset.getString("LOCATION"));
					

					wBean.setHumidity(resultset.getString("HUMIDITY"));
					wBean.setTemperature(resultset.getString("TEMPERATURE"));
					wBean.setWindspeed(resultset.getString("WINDSPEED"));
					wBean.setRainfall(resultset.getString("RAINFALL"));
					//stockBean.setStockName(resultset.getString(2));
					//map.put(loc,resultset.getString(2));
					update1.add(wBean);
					
							
				}
			 
		
			 //map = new HashMap<String,String>();
			 
			/*while(resultset.next()) {
				WeatherBean weatherBean = new WeatherBean();
				weatherBean.setHumidity(resultset.getString("HUMIDITY"));
				weatherBean.setRainfall(resultset.getString("RAINFALL"));
				weatherBean.setTemperature(resultset.getString("TEMPERATURE"));
				weatherBean.setWindspeed(resultset.getString("WINDSPEED"));
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				update1.add(weatherBean);*/
				
						
			//}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
	}
	
	
	
	
	public List<WeatherBean> getUpdate2(String place,String sr,String ss,String mr,String ms)
	{
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
	//	Map map=null;
		ResultSet resultset = null;
		List<WeatherBean> update1=null;
		//String searchQuery = "SELECT *  from T_XBBNHF7_WEATHER1";
		String searchQuery = "INSERT INTO T_XBBNHF7_WEATHER2 VALUES (?,?, ?, ?, ?)";

		try {
			 stmt = conn.prepareStatement(searchQuery);		
			
			 
			
			 stmt.setString(1, place);
			 stmt.setString(2, sr);
			 stmt.setString(3, ss);
			 stmt.setString(4, mr);
			 stmt.setString(5, ms);
					
			
			  stmt.executeUpdate();	
			 update1=new ArrayList<WeatherBean>();
			 
			
			 //map = new HashMap<String,String>();
			 
			/*while(resultset.next()) {
				WeatherBean weatherBean = new WeatherBean();
				weatherBean.setHumidity(resultset.getString("HUMIDITY"));
				weatherBean.setRainfall(resultset.getString("RAINFALL"));
				weatherBean.setTemperature(resultset.getString("TEMPERATURE"));
				weatherBean.setWindspeed(resultset.getString("WINDSPEED"));
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				update1.add(weatherBean);*/
				
						
			//}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
	
	
	}
	
	
	
	public List<WeatherBean> getUpdate3()
	{
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
	//	Map map=null;
		ResultSet resultset = null;
		List<WeatherBean> update1=null;
		//String searchQuery = "SELECT *  from T_XBBNHF7_WEATHER1";
		String searchQuery = "SELECT * FROM T_XBBNHF7_WEATHER2 where PLACE='TamilNadu'";

		try {
			 stmt = conn.prepareStatement(searchQuery);		
					
			
			  resultset=stmt.executeQuery();	
			  update1=new ArrayList<WeatherBean>();
			  
			  while(resultset.next()) {
					WeatherBean wBean = new WeatherBean();
					wBean.setPlace(resultset.getString("PLACE"));
					

					wBean.setSunrise(resultset.getString("SUNRISE"));
					wBean.setSunset(resultset.getString("SUNSET"));
					wBean.setMoonrise(resultset.getString("MOONRISE"));
					wBean.setMoonset(resultset.getString("MOONSET"));
					//stockBean.setStockName(resultset.getString(2));
					//map.put(loc,resultset.getString(2));
					update1.add(wBean);
					
							
				}
			 
		
			 //map = new HashMap<String,String>();
			 
			/*while(resultset.next()) {
				WeatherBean weatherBean = new WeatherBean();
				weatherBean.setHumidity(resultset.getString("HUMIDITY"));
				weatherBean.setRainfall(resultset.getString("RAINFALL"));
				weatherBean.setTemperature(resultset.getString("TEMPERATURE"));
				weatherBean.setWindspeed(resultset.getString("WINDSPEED"));
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				update1.add(weatherBean);*/
				
						
			//}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
	}
	
	
	
	
	
	
	
	
	
	public void setstatus(String city,String temp,String hu,String rf,String ws)
	{
	       Connection con = ConnectionManager.getConnection();
	 PreparedStatement stmt = null;
	 try{
	 stmt = con.prepareStatement("update T_XBBNHF7_WEATHER1 set TEMPERATURE=?,HUMIDITY=?,WINDSPEED=?,RAINFALL=? WHERE LOCATION=?  ");
	 stmt.setString(1,temp);
	 stmt.setString(2,hu);
	 stmt.setString(3,ws);
	 stmt.setString(4,rf);
	 stmt.setString(5,city);
	 stmt.executeUpdate();
	 }
	 catch (SQLException e) {
	              // TODO Auto-generated catch block
	              e.printStackTrace();
	       }      


	}
	
	public void setstatus1(String place,String sr,String ss,String mr,String ms)
	{
	       Connection con = ConnectionManager.getConnection();
	 PreparedStatement stmt = null;
	 try{
	 stmt = con.prepareStatement("update T_XBBNHF7_WEATHER2 set SUNRISE=?,SUNSET=?,MOONRISE=?,MOONSET=? WHERE PLACE=?  ");
	 stmt.setString(1,sr);
	 stmt.setString(2,ss);
	 stmt.setString(3,mr);
	 stmt.setString(4,ms);
	 stmt.setString(5,place);
	 stmt.executeUpdate();
	 }
	 catch (SQLException e) {
	              // TODO Auto-generated catch block
	              e.printStackTrace();
	       }      


	}


	public List<WeatherBean> details1() {
		
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		PreparedStatement stmt1 = null;
	//	Map map=null;
		ResultSet resultset = null;
		ResultSet resultset1 = null;
		List<WeatherBean> update1=null;
		List<WeatherBean> update2=null;
		//String searchQuery = "SELECT *  from T_XBBNHF7_WEATHER1";
		//String searchQuery = "SELECT * FROM T_XBBNHF7_WEATHER2";
		String searchQuery1 = "SELECT * FROM T_XBBNHF7_WEATHER1";

		try {
			 stmt = conn.prepareStatement(searchQuery1);	
			// stmt1 = conn.prepareStatement(searchQuery);	
					
			
			 resultset=stmt.executeQuery();
			 // resultset1=stmt1.executeQuery();	

			  update1=new ArrayList<WeatherBean>();
			 // update2=new ArrayList<WeatherBean>();
			  
			/*  while(resultset.next()) {
					WeatherBean wBean = new WeatherBean();
					wBean.setPlace(resultset.getString("PLACE"));
					

					wBean.setSunrise(resultset.getString("SUNRISE"));
					wBean.setSunset(resultset.getString("SUNSET"));
					wBean.setMoonrise(resultset.getString("MOONRISE"));
					wBean.setMoonset(resultset.getString("MOONSET"));
					wBean.setMoonset(resultset.getString("TEMPERATURE"));
					
					update1.add(wBean);
					
							
				}*/
			  while(resultset.next()) {
					WeatherBean wBean = new WeatherBean();
					wBean.setHumidity(resultset.getString("HUMIDITY"));
					wBean.setWindspeed(resultset.getString("WINDSPEED"));
					wBean.setRainfall(resultset.getString("RAINFALL"));
					wBean.setCity(resultset.getString("LOCATION"));
					wBean.setTemperature(resultset.getString("TEMPERATURE"));
					update1.add(wBean);
					}
			 // update1.addAll(update2);
			/*  Iterator<WeatherBean> itr=update2.iterator();
			  while(itr.hasNext())
			  {
				  WeatherBean wb=itr.next();
				  System.out.println(wb.getHumidity()+wb.getMoonrise());
			  }*/
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
		
		
	}


	public List<WeatherBean> details2() {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		PreparedStatement stmt1 = null;
	
		ResultSet resultset = null;
	
		List<WeatherBean> update1=null;
	
		
		String searchQuery1 = "SELECT * FROM T_XBBNHF7_WEATHER2";

		try {
			 stmt = conn.prepareStatement(searchQuery1);	
			
			 resultset=stmt.executeQuery();
		
			  update1=new ArrayList<WeatherBean>();
			
			  while(resultset.next()) {
					WeatherBean wBean = new WeatherBean();
					wBean.setPlace(resultset.getString("PLACE"));
					wBean.setSunrise(resultset.getString("SUNRISE"));
					wBean.setSunset(resultset.getString("SUNSET"));
					wBean.setMoonrise(resultset.getString("MOONRISE"));
					wBean.setMoonset(resultset.getString("MOONSET"));
			
					update1.add(wBean);
					
							
				}
			  
			  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
		
	}
	
	
	
	
	
	
	public List<WeatherBean> abc() {
		
		
		
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		PreparedStatement stmt1 = null;
	
		ResultSet resultset = null;
		ResultSet resultset1 = null;
	
		List<WeatherBean> update1=null;
	
		
		String searchQuery = "SELECT * FROM T_XBBNHF7_WEATHER1";
		String searchQuery1 = "SELECT * FROM T_XBBNHF7_WEATHER2";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			 stmt1 = conn.prepareStatement(searchQuery1);
			
			 resultset=stmt.executeQuery();
			 resultset1=stmt1.executeQuery();
			  update1=new ArrayList<WeatherBean>();
			
			  while(resultset1.next()) {
					WeatherBean wBean = new WeatherBean();
					wBean.setPlace(resultset1.getString("PLACE"));
					wBean.setSunrise(resultset1.getString("SUNRISE"));
					wBean.setSunset(resultset1.getString("SUNSET"));
					wBean.setMoonrise(resultset1.getString("MOONRISE"));
					wBean.setMoonset(resultset1.getString("MOONSET"));
			
					update1.add(wBean);
					
							
				}
			  while(resultset.next()) {
					WeatherBean wBean = new WeatherBean();
					wBean.setHumidity(resultset.getString("HUMIDITY"));
					wBean.setWindspeed(resultset.getString("WINDSPEED"));
					wBean.setRainfall(resultset.getString("RAINFALL"));
					wBean.setCity(resultset.getString("LOCATION"));
					wBean.setTemperature(resultset.getString("TEMPERATURE"));
					update1.add(wBean);
					}
			  
			  
			  
			  
			
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		
		
		
		return update1;
		}
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

