package com.wms.servletcontroller;


	
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping(value = "/def")
public class UserController {


    @RequestMapping(value = "/hij", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
      public List<UserBean> getDetails() {
      UserDao dd = new UserDao();
      List<UserBean> li = dd.details1(); 
      return li;
  }
  }


	

