package com.wms.servletcontroller;

public class WeatherBean {
private String city;
private String temperature,windspeed,rainfall,humidity;
private String sunrise,sunset,moonrise,moonset,place;



public String getSunrise() {
	return sunrise;
}

public void setSunrise(String sunrise) {
	this.sunrise = sunrise;
}

public String getSunset() {
	return sunset;
}

public void setSunset(String sunset) {
	this.sunset = sunset;
}

public String getMoonrise() {
	return moonrise;
}

public void setMoonrise(String moonrise) {
	this.moonrise = moonrise;
}

public String getMoonset() {
	return moonset;
}

public void setMoonset(String moonset) {
	this.moonset = moonset;
}

public String getPlace() {
	return place;
}

public void setPlace(String place) {
	this.place = place;
}

public String getTemperature() {
	return temperature;
}

public void setTemperature(String temperature) {
	this.temperature = temperature;
}

public String getWindspeed() {
	return windspeed;
}

public void setWindspeed(String windspeed) {
	this.windspeed = windspeed;
}

public String getRainfall() {
	return rainfall;
}

public void setRainfall(String rainfall) {
	this.rainfall = rainfall;
}

public String getHumidity() {
	return humidity;
}

public void setHumidity(String humidity) {
	this.humidity = humidity;
}



public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

//public String getStatus() {
	
	// TODO Auto-generated method stub
	//return null;
}

