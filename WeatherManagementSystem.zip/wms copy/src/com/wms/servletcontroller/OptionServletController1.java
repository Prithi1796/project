package com.wms.servletcontroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class OptionServletController1 extends HttpServlet {
public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
                {
                                Cookie ck[]=request.getCookies();
                                PrintWriter out = response.getWriter();
                
                                PreparedStatement stmt = null;
                                ResultSet rs=null;
                        
                                        
                                                        int id=Integer.parseInt(request.getParameter("id"));
                                                        Connection con = ConnectionManager.getConnection();
                               
                                
                                try {
                                                                        stmt = con.prepareStatement("select * from T_XBBNHF7_MET_HEAD where MID = ?");
                                            stmt.setInt(1,id);
                               rs=stmt.executeQuery();
                        if(rs.next()){
                                                        RequestDispatcher requestDispatcher = request.getRequestDispatcher("mh.html");
                                                        requestDispatcher.forward(request, response);
                                        }
                        else
                        {
                        	 out.println("<script type=\"text/javascript\">");

                  		    out.println("alert('Invalid UserId!');");
                  		    

                  		    out.println("location='blooger_or_methead.html';");

                  		    out.println("</script>");
                        }
                                        }
                                catch (SQLException e) {
                                                                        // TODO Auto-generated catch block
                                                                        e.printStackTrace();
                                                        }
                                        }
                                        

                
                                
                }

