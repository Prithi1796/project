package com.wms.servletcontroller;

import java.util.List;

public class AdminApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AdminDao adminDao=new AdminDao();
		adminDao.getUpdate();

	}

}
