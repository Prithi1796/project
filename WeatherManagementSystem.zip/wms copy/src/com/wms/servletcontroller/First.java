package com.wms.servletcontroller;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class First extends HttpServlet
{
	 private static final long serialVersionUID = 1L;

     public First() {
                     super();
                     // TODO Auto-generated constructor stub
     }

     protected void doPost(HttpServletRequest request, HttpServletResponse response)
                                     throws ServletException, IOException {
                     PrintWriter out = response.getWriter();
                     String userId = request.getParameter("uname");
                     String passWord = request.getParameter("psw");
     
                    BloggerDao bloggerdao=new BloggerDao();
                     
                     
                     try {
							if(bloggerdao.isMatch(userId,passWord)) {
								
				                
								 RequestDispatcher requestDispatcher = request.getRequestDispatcher("blooger_or_methead.html");

                                /* Cookie ck=new Cookie("LoginCookie",userId);

                                 ck.setMaxAge(15);

                                 response.addCookie(ck);*/
								 HttpSession session=request.getSession();  
                                 requestDispatcher.forward(request, response);
                                 session.setAttribute("uname",userId);  



				                
							} 
							/*

                                                                                                

 

                                                                                                

*/
							else  
							{
							                
								out.println("<script type=\"text/javascript\">");
								out.println("alert('Invalid UserName or Password!');");

                                out.println("location='login1.html';");

                                out.println("</script>");
							                
							                
							}
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                     // doPost(request, response);
     }



}
