package com.wms.servletcontroller;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;



public class TestRowMapper implements RowMapper<UserBean> {

    public UserBean mapRow(ResultSet rs, int rownum) throws SQLException {

            // TODO Auto-generated method stub      

            

        UserBean user=new UserBean(); 

          

            user.setM_update(rs.getString(1));

            user.setLoctaion2(rs.getString(2));

            user.setB_update(rs.getString(3));           

          

            

            return user;

    

    }


}
