package com.wms.servletcontroller;

public class MetHeadBean {
	private int mid;
	private String name,loctaion1,m_update;
	
	public int getmid() {
		return mid;
	}
	public void setmid(int mid) {
		this.mid = mid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLoctaion1() {
		return loctaion1;
	}
	public void setLoctaion1(String loctaion1) {
		this.loctaion1 = loctaion1;
	}
	
	public String getm_update() {
		return m_update;
	}
	public void setm_update(String m_update) {
		this.m_update = m_update;
	}

}
