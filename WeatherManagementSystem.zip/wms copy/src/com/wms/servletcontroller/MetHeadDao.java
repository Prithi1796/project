package com.wms.servletcontroller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MetHeadDao {

	
	public List<MetHeadBean> makeUpdate(int id,String name,String mlocation,String mupdate ) {
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
	
		List<MetHeadBean> update1=null;
		ResultSet resultset = null;
		
		String searchQuery = "INSERT INTO T_XBBNHF7_MET_HEAD VALUES (?, ?, ?, ?)";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			 stmt.setInt(1, id);
			 stmt.setString(2, name);
			 stmt.setString(3, mlocation);
			 stmt.setString(4, mupdate);
					
			
			  stmt.executeUpdate();	
			 update1=new ArrayList<MetHeadBean>();
			 
			
			 //map = new HashMap<String,String>();
			 
		/*	while(resultset.next()) {
				MetHeadBean mcBean = new MetHeadBean();
				//bloggerBean.setStatus1(resultset.getString("UPDATES"));
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				mcBean.setmid(resultset.getInt("BID"));
				mcBean.setLoctaion1(resultset.getString("M_LOCATION"));

				mcBean.setName(resultset.getString("NAME"));
				mcBean.setm_update(resultset.getString("M_UPDATE"));

						
				update1.add(mcBean);
				
						
			}*/
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
	
	}
	public void UpdateStatus(String update,String location)
	{
	       Connection con = ConnectionManager.getConnection();
	 PreparedStatement stmt = null;
	 try{
	 stmt = con.prepareStatement("update T_XBBNHF7_MET_HEAD set M_UPDATE=? WHERE M_LOCATION=?  ");
	 stmt.setString(1,update);
	 System.out.println(update);
	 stmt.setString(2,location);
	 System.out.println(location);
	 
 stmt.executeUpdate();
	 }
	 catch (SQLException e) {
	              // TODO Auto-generated catch block
	              e.printStackTrace();
	       }      


	}
	
	public List callAnotherTable() throws SQLException {
	    // TODO Auto-generated method stub
	    Connection conn = ConnectionManager.getConnection();
	    PreparedStatement stmt1 = null;
	    String searchQuery = "SELECT * FROM T_XBBNHF7_MET_HEAD";
	    List<MetHeadBean> update3=null;;
	    ResultSet resultset1=null;
	    try {
	                    stmt1 = conn.prepareStatement(searchQuery);
	                                     

	                    resultset1 = stmt1.executeQuery();        
	                   update3=new ArrayList<MetHeadBean>();
	                    while(resultset1.next())

	                    {    
	                    	MetHeadBean mbean=new MetHeadBean();
	                                    mbean.setLoctaion1(resultset1.getString("M_LOCATION"));
	                                    mbean.setm_update(resultset1.getString("M_UPDATE"));
	                                    mbean.setmid(resultset1.getInt("MID"));
	                                    mbean.setName(resultset1.getString("NAME"));

	                                    update3.add(mbean);

	                                    
	                    }



	    }
	    catch (SQLException e) {
	                    // TODO Auto-generated catch block
	                    e.printStackTrace();
	    }              
	    finally{
	                    try {
	                                    if(resultset1 != null)
	                                                    resultset1.close();
	                                    if(stmt1 != null)                                                                 
	                                                    stmt1.close();                                                    
	                                    conn.commit();
	                                    if(conn != null)
	                                                    conn.close();
	                    }                                              
	                    catch (SQLException e) {
	                                    // TODO Auto-generated catch block
	                                    e.printStackTrace();
	                    }
	    }
	    return update3;                
	}

	
	
	
	
}
