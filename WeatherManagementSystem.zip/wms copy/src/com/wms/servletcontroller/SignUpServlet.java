package com.wms.servletcontroller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SignUpServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
		boolean b=false;
		
		PrintWriter out = response.getWriter();
		BloggerDao bdao=new BloggerDao();
		String userId=request.getParameter("email");
		String c=request.getParameter("radio");

	
		try {
			b=bdao.isAvailable(userId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			out.println("UserId already exists");
		}
	if(b)
	{
		 out.println("<script type=\"text/javascript\">");

		    out.println("alert('UserId already exists!');");
		    

		    out.println("location='signup1.html';");

		    out.println("</script>");
		
	}
	else{
		 
        String pswd=request.getParameter("psw");

        String rpswd=request.getParameter("psw-repeat");

        String email=request.getParameter("email");
        if(pswd.equals(rpswd)==false)

        {

               

            out.println("<script type=\"text/javascript\">");

    out.println("alert('Password Mismatch');");
    

    out.println("location='signup1.html';");

    out.println("</script>");

        }
        else

        {
       
        	
        	
        	RequestDispatcher requestDispatcher = request.getRequestDispatcher("SignUp.jsp");

                      requestDispatcher.forward(request, response);
        }




       

	}
	
	}

}
