package com.wms.servletcontroller;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
	import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



	@RestController
	@RequestMapping(value = "/abc")

	public class BloggerController {


		
		 
		  @RequestMapping(value = "/all" , method = RequestMethod.GET )
		  public List<BloggerBean> get() {
				
	    	
			List<BloggerBean> list = new ArrayList<BloggerBean>(); 
			BloggerDao bdao=new BloggerDao();
			try {
				list= bdao.callAnotherTable();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
	    	return list;
	      }	
		

		  @RequestMapping(value = "/all1" , method = RequestMethod.DELETE)
		  
		  public void get1() {
	    	
				String loc="Pallavaram";

			BloggerDao bdao=new BloggerDao();
		
			bdao.DeleteStatus(loc);
			
			
	    
	      }	 
		  
		  @RequestMapping(value = "/all2" , method = RequestMethod.GET )
		  public List<MetHeadBean> get2() {
				

	    	
			List<MetHeadBean> list = new ArrayList<MetHeadBean>(); 
			MetHeadDao mdao=new MetHeadDao();
			try {
				list= mdao.callAnotherTable();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
	    	return list;
	      }	
		
		
			

				@RequestMapping(value = "/all3", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
			    public List<UserBean> getDetails() {
					UserDao dd = new UserDao();
					List<UserBean> li = dd.details1();		
					return li;
			}

				@RequestMapping(value = "/all4", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
			    public List<WeatherBean> getDetails1() {
					WeatherDao dd = new WeatherDao();
					List<WeatherBean> li = dd.details1();		
					return li;

			}
	    
				@RequestMapping(value = "/all5", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
			    public List<WeatherBean> getDetails2() {
					WeatherDao dd = new WeatherDao();
					List<WeatherBean> li = dd.details2();		
					return li;

			}
				
				@RequestMapping(value = "/all6", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
			    public List<WeatherBean> getDetails3() {
					WeatherDao dd = new WeatherDao();
					List<WeatherBean> li = dd.abc();		
					return li;

			}
				
				
	
	}


