package com.wms.servletcontroller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.inautix.sample.weather.BloggerBean;

public class UserDao {
	ArrayList<BloggerBean> update3=null;
	ArrayList<MetHeadBean> update2=null;
	
	public ArrayList<UserBean> makeUpdate(String location)
	{
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
	//	Map map=null;
		ResultSet resultset = null;
		ArrayList<UserBean> update1=null;
		
		String searchQuery = "SELECT *  from T_XBBNHF7_ADMIN WHERE LOCATION = ? ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, location);		
			
			 resultset = stmt.executeQuery();	
			 update1=new ArrayList<UserBean>();
			 
			
			 //map = new HashMap<String,String>();
			 
			while(resultset.next()) {
				UserBean userBean = new UserBean();
				userBean.setLoctaion2(resultset.getString("LOCATION"));
				userBean.setM_update(resultset.getString("M_UPDATE"));
				userBean.setB_update(resultset.getString("B_UPDATE"));
				
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				update1.add(userBean);
				
						
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
	}
    public List callAnotherTable(String location) throws SQLException {
        // TODO Auto-generated method stub
        Connection conn = ConnectionManager.getConnection();
        PreparedStatement stmt1 = null;
        String searchQuery = "SELECT * FROM T_XBBNHF7_BLOGGER where BLOCATION=? ";
        ResultSet resultset1=null;
        try {
                        stmt1 = conn.prepareStatement(searchQuery);
                        stmt1.setString(1, location);                        

                        resultset1 = stmt1.executeQuery();        
                        update3=new ArrayList<BloggerBean>();
                        while(resultset1.next())

                        {    
                                        BloggerBean bbean=new BloggerBean();
                                        bbean.setLoctaion1(resultset1.getString("BLOCATION"));
                                        bbean.setB_update(resultset1.getString("B_UPDATE"));
                                        

                                        update3.add(bbean);

                                        
                        }



        }
        catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
        }              
        finally{
                        try {
                                        if(resultset1 != null)
                                                        resultset1.close();
                                        if(stmt1 != null)                                                                 
                                                        stmt1.close();                                                    
                                        conn.commit();
                                        if(conn != null)
                                                        conn.close();
                        }                                              
                        catch (SQLException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                        }
        }
        return update3;                
} 

public List callSecondTable(String location) throws SQLException {
        Connection conn = ConnectionManager.getConnection();
        PreparedStatement stmt1 = null;
        String searchQuery = "SELECT * FROM T_XBBNHF7_MET_HEAD where M_LOCATION=? ";
        ResultSet resultset1=null;
        try {
                        stmt1 = conn.prepareStatement(searchQuery);
                        stmt1.setString(1, location);                        

                        resultset1 = stmt1.executeQuery();        
                        update2=new ArrayList<MetHeadBean>();
                        while(resultset1.next())

                        {    
                        	MetHeadBean mbean=new MetHeadBean();
                                        mbean.setLoctaion1(resultset1.getString("M_LOCATION"));

                                        mbean.setm_update(resultset1.getString("M_UPDATE"));


                                        update2.add(mbean);


                        }



        }
        catch (SQLException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
        }              
        finally{
                        try {
                                        if(resultset1 != null)
                                                        resultset1.close();
                                        if(stmt1 != null)                                                                 
                                                        stmt1.close();                                                    
                                        conn.commit();
                                        if(conn != null)
                                                        conn.close();
                        }                                              
                        catch (SQLException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                        }
        }
        return update2;                
}
public List<UserBean> details1() {
	// TODO Auto-generated method stub
	// TODO Auto-generated method stub
			Connection conn = ConnectionManager.getConnection();
			PreparedStatement stmt = null;
		//	Map map=null;
			ResultSet resultset = null;
			ArrayList<UserBean> update1=null;
			
			String searchQuery = "SELECT *  from T_XBBNHF7_ADMIN";
			try {
				 stmt = conn.prepareStatement(searchQuery);
					
				
				 resultset = stmt.executeQuery();	
				 update1=new ArrayList<UserBean>();
				 
				
				 //map = new HashMap<String,String>();
				 
				while(resultset.next()) {
					UserBean userBean = new UserBean();
					userBean.setLoctaion2(resultset.getString("LOCATION"));
					userBean.setM_update(resultset.getString("M_UPDATE"));
					userBean.setB_update(resultset.getString("B_UPDATE"));
					
					//stockBean.setStockName(resultset.getString(2));
					//map.put(loc,resultset.getString(2));
					update1.add(userBean);
					
							
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			
			
			
			
			return update1;
} 

}


