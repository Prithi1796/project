package com.wms.servletcontroller;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping(value = "/def")

public class AdminController {
	
			String loc="Pallavaram";
			 
			  @RequestMapping(value = "/all" , method = RequestMethod.GET )
			  public List<AdminBean> get() {
					//String loc="Pallavaram";

		    	
				List<AdminBean> list = new ArrayList<AdminBean>(); 
				AdminDao bdao=new AdminDao();
				try {
					list= bdao.callAnotherTable();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		    	return list;
		      }	
			
}
