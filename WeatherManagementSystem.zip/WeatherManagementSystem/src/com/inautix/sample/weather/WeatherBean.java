package com.inautix.sample.weather;

public class WeatherBean {
private String location;
private String temperature,windspeed,rainfall,humidity;



public String getTemperature() {
	return temperature;
}

public void setTemperature(String temperature) {
	this.temperature = temperature;
}

public String getWindspeed() {
	return windspeed;
}

public void setWindspeed(String windspeed) {
	this.windspeed = windspeed;
}

public String getRainfall() {
	return rainfall;
}

public void setRainfall(String rainfall) {
	this.rainfall = rainfall;
}

public String getHumidity() {
	return humidity;
}

public void setHumidity(String humidity) {
	this.humidity = humidity;
}



public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}

//public String getStatus() {
	
	// TODO Auto-generated method stub
	//return null;
}

