package com.inautix.sample.weather;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MetHeadDao {

	
	public List<MetHeadBean> makeUpdate(int id,String name,String mlocation,String mupdate ) {
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
	
		List<MetHeadBean> update1=null;
		ResultSet resultset = null;
		
		String searchQuery = "INSERT INTO T_XBBNHF7_MET_HEAD VALUES (?, ?, ?, ?)";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			 stmt.setInt(1, id);
			 stmt.setString(2, name);
			 stmt.setString(3, mlocation);
			 stmt.setString(4, mupdate);
					
			
			  stmt.executeUpdate();	
			 update1=new ArrayList<MetHeadBean>();
			 
			
			 //map = new HashMap<String,String>();
			 
		/*	while(resultset.next()) {
				MetHeadBean mcBean = new MetHeadBean();
				//bloggerBean.setStatus1(resultset.getString("UPDATES"));
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				mcBean.setmid(resultset.getInt("BID"));
				mcBean.setLoctaion1(resultset.getString("M_LOCATION"));

				mcBean.setName(resultset.getString("NAME"));
				mcBean.setm_update(resultset.getString("M_UPDATE"));

						
				update1.add(mcBean);
				
						
			}*/
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
	
	}

}
