package com.inautix.sample.weather;
import java.sql.*;
import java.util.*;
public class WeatherDao {
	
	public List<WeatherBean> getUpdate()
	{
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
	//	Map map=null;
		ResultSet resultset = null;
		List<WeatherBean> update1=null;
		String searchQuery = "SELECT *  from T_XBBNHF7_WEATHER1";
		try {
			 stmt = conn.prepareStatement(searchQuery);		
			
			 resultset = stmt.executeQuery();	
			 update1=new ArrayList<WeatherBean>();
			 
			
			 //map = new HashMap<String,String>();
			 
			while(resultset.next()) {
				WeatherBean weatherBean = new WeatherBean();
				weatherBean.setHumidity(resultset.getString("HUMIDITY"));
				weatherBean.setRainfall(resultset.getString("RAINFALL"));
				weatherBean.setTemperature(resultset.getString("TEMPERATURE"));
				weatherBean.setWindspeed(resultset.getString("WINDSPEED"));
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				update1.add(weatherBean);
				
						
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
	}

}
