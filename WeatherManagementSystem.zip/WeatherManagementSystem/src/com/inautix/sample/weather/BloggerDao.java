package com.inautix.sample.weather;

import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class BloggerDao {
public ArrayList<BloggerBean> makeUpdate(int id,String name,String blocation,String bupdate)
	{
		// TODO Auto-generated method stub
		java.sql.Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
	//	Map map=null;
		ResultSet resultset = null;
		ArrayList<BloggerBean> update1=null;
		String searchQuery = "INSERT INTO T_XBBNHF7_BLOGGER VALUES (?, ?, ?, ?)";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			 stmt.setInt(1, id);
			 stmt.setString(2, name);
			 stmt.setString(3, blocation);
			 stmt.setString(4, bupdate);
					
			
			 stmt.executeUpdate();	
			 update1=new ArrayList<BloggerBean>();
			 
			
			 //map = new HashMap<String,String>();
			 
			/*while(resultset.next()) {
				BloggerBean bloggerBean = new BloggerBean();
				//bloggerBean.setStatus1(resultset.getString("UPDATES"));
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				bloggerBean.setBid(resultset.getInt("BID"));
				bloggerBean.setLoctaion1(resultset.getString("BLOCATION"));

				bloggerBean.setName(resultset.getString("NAME"));
				bloggerBean.setB_update(resultset.getString("B_UPDATE"));
				

						
				update1.add(bloggerBean);
				
						
			}*/
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
	
		return update1;
	}

public boolean isMatch(String userId, String passWord) throws SQLException {
	// TODO Auto-generated method stub
	 Connection con = ConnectionManager.getConnection();
     PreparedStatement stmt1 = null;
     
            stmt1 = con.prepareStatement("select * from T_XBBNHF7_CREDENTIALS where USER_NAME= ? AND PASSWORD= ?");
            stmt1.setString(1, userId);
            stmt1.setString(2, passWord);
     
     boolean isMatch = false;
     ResultSet rs = null;
     
     rs = stmt1.executeQuery();
            
     while(rs.next())
     {
            isMatch = true;
     }
     con.close();
    
     
	return isMatch;
}

	}


