package com.inautix.sample.weather;


public class BloggerBean {
	private int bid;
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLoctaion1() {
		return loctaion1;
	}
	public void setLoctaion1(String loctaion1) {
		this.loctaion1 = loctaion1;
	}
	private String name,loctaion1,b_update;
	public String getB_update() {
		return b_update;
	}
	public void setB_update(String b_update) {
		this.b_update = b_update;
	}
	

}
