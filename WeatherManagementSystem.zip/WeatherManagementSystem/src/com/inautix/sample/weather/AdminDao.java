package com.inautix.sample.weather;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AdminDao {
	public void  getUpdate()
	{
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		PreparedStatement stmt1 = null;
	//	Map map=null;
		ResultSet resultset = null;
		List<AdminBean> update1=null;
		String searchQuery = "INSERT INTO T_XBBNHF7_ADMIN (LOCATION,M_UPDATE,B_UPDATE) SELECT T_XBBNHF7_MET_HEAD.M_LOCATION,M_UPDATE,B_UPDATE FROM T_XBBNHF7_MET_HEAD JOIN T_XBBNHF7_BLOGGER ON T_XBBNHF7_MET_HEAD.M_LOCATION=T_XBBNHF7_BLOGGER.BLOCATION";
		//String searchQuery1= "INSERT INTO T_XBBNHF7_ADMIN (B_UPDATE,LOCATION) SELECT B_UPDATE,BLOCATION FROM T_XBBNHF7_BLOGGER";
		
		try {
			 stmt = conn.prepareStatement(searchQuery);
			 //stmt1 = conn.prepareStatement(searchQuery1);
			//stmt.setString(1, location);		
			stmt.executeUpdate();
			//stmt1.executeUpdate();
			// resultset = stmt.executeQuery();	
			 //update1=new ArrayList<WeatherBean>();
			 
			
			 //map = new HashMap<String,String>();
			 
			/*while(resultset.next()) {
				WeatherBean weatherBean = new WeatherBean();
				weatherBean.setStatus1(resultset.getString("UPDATES"));
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				update1.add(adminBean);
				
						
			}*/
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		//return update1;
	}

}
