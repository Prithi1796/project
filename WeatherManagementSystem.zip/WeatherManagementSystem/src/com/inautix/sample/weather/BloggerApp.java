package com.inautix.sample.weather;


import java.util.*;
public class BloggerApp {
	

	

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter blogger id");
			int id=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter name");
			String name=sc.nextLine();
			System.out.println("Enter location");
			String location=sc.nextLine();
			
			System.out.println("Enter update");
			String bupdate=sc.nextLine();
			/*WeatherDao weatherDao= new WeatherDao();
			Map<String,String> map= new HashMap<String,String>();
			
			String update=weatherDao.getStatus(loc);
			map.put(loc, update);
			System.out.println(map);*/
			BloggerDao bloggerDao=new BloggerDao();
			//WeatherBean weatherBean=new WeatherBean();
		//	weatherBean.setLocation("pallavaram");
			//String update= weatherDao.getStatus(weatherBean.getLocation());
			//Map<String,String> map = new HashMap<String,String>();
			//if(map.containsKey(weatherBean.getLocation()))
				//System.out.println(map);
			//<WeatherBean> update1=weatherDao.getStatus(location);
		List<BloggerBean> update1= bloggerDao.makeUpdate(id, name, location, bupdate);
		
			
			/*Iterator<BloggerBean> itr=update1.iterator();
			while(itr.hasNext())
			{
				BloggerBean bloggerBean=itr.next();
				System.out.print(bloggerBean.getBid()+ " ");
				System.out.print(bloggerBean.getName()+ " ");
				System.out.print(bloggerBean.getLoctaion1()+ " ");
				System.out.println(bloggerBean.getB_update()+ " ");
				

				
			}*/
				
			

		}

	}


