package com.inautix.sample.weather;

public class UserBean {

private String loctaion2;
private String m_update,b_update;

	public String getM_update() {
	return m_update;
}
public void setM_update(String m_update) {
	this.m_update = m_update;
}
public String getB_update() {
	return b_update;
}
public void setB_update(String b_update) {
	this.b_update = b_update;
}
	public String getLoctaion2() {
		return loctaion2;
	}
	public void setLoctaion2(String loctaion2) {
		this.loctaion2 = loctaion2;
	}
	
	
	
	

}



