package com.inautix.sample.weather;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class UserApp {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter location");
		String location=sc.nextLine();
		/*WeatherDao weatherDao= new WeatherDao();
		Map<String,String> map= new HashMap<String,String>();
		
		String update=weatherDao.getStatus(loc);
		map.put(loc, update);
		System.out.println(map);*/
		UserDao userDao=new UserDao();
		//WeatherBean weatherBean=new WeatherBean();
	//	weatherBean.setLocation("pallavaram");
		//String update= weatherDao.getStatus(weatherBean.getLocation());
		//Map<String,String> map = new HashMap<String,String>();
		//if(map.containsKey(weatherBean.getLocation()))
			//System.out.println(map);
		//<WeatherBean> update1=weatherDao.getStatus(location);
	List<UserBean> update1= userDao.makeUpdate(location);
	
		
		Iterator<UserBean> itr=update1.iterator();
		while(itr.hasNext())
		{
			UserBean userBean=itr.next();
			System.out.print(userBean.getLoctaion2()+ ": ");
			System.out.print(userBean.getB_update()+ " ");
			System.out.print(userBean.getM_update()+ " ");
			
			

			
		}
			
		

	}

}
