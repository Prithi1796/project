package com.inautix.sample.weather;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class MetHeadApp {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter methead id");
		int id=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter name");
		String name=sc.nextLine();
		System.out.println("Enter location");
		String location=sc.nextLine();
		
		System.out.println("Enter mpdate");
		String mupdate=sc.nextLine();
		
		// TODO Auto-generated method stub
		//String location="pozhichalur";
		/*WeatherDao weatherDao= new WeatherDao();
		Map<String,String> map= new HashMap<String,String>();
		
		String update=weatherDao.getStatus(loc);
		map.put(loc, update);
		System.out.println(map);*/
		MetHeadDao mhDao=new MetHeadDao();
		//WeatherBean weatherBean=new WeatherBean();
	//	weatherBean.setLocation("pallavaram");
		//String update= weatherDao.getStatus(weatherBean.getLocation());
		//Map<String,String> map = new HashMap<String,String>();
		//if(map.containsKey(weatherBean.getLocation()))
			//System.out.println(map);
		//<WeatherBean> update1=weatherDao.getStatus(location);
	List<MetHeadBean> update1= mhDao.makeUpdate(id, name, location, mupdate);
	
		
		//Iterator<MetHeadBean> itr=update1.iterator();
		/*while(itr.hasNext())
		{
			MetHeadBean mhBean=itr.next();
			System.out.print(mhBean.getmid()+ " ");
			System.out.print(mhBean.getName()+ " ");
			System.out.print(mhBean.getLoctaion1()+ " ");
			System.out.print(mhBean.getm_update()+ " ");
			

			
		}*/
			
		

	}

}
