package com.inautix.sample.weather;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class UserDao {
	public ArrayList<UserBean> makeUpdate(String location)
	{
		// TODO Auto-generated method stub
		java.sql.Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
	//	Map map=null;
		ResultSet resultset = null;
		ArrayList<UserBean> update1=null;
		String searchQuery = "SELECT *  from T_XBBNHF7_ADMIN WHERE LOCATION = ? ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, location);		
			
			 resultset = stmt.executeQuery();	
			 update1=new ArrayList<UserBean>();
			 
			
			 //map = new HashMap<String,String>();
			 
			while(resultset.next()) {
				UserBean userBean = new UserBean();
				userBean.setLoctaion2(resultset.getString("LOCATION"));
				userBean.setM_update(resultset.getString("M_UPDATE"));
				userBean.setB_update(resultset.getString("B_UPDATE"));
				
				//stockBean.setStockName(resultset.getString(2));
				//map.put(loc,resultset.getString(2));
				update1.add(userBean);
				
						
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		
		
		return update1;
	}
}
